﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMotor : MonoBehaviour
{
    //khai bao toc do chay
    private float speed = 5.0f;//toc do theo truc z
    private CharacterController controller;//khai bao bo dieu khien
    //toc do ngang
    private float verticalVelocity = 0.0f;
    private float gravity=10.0f;//trong luong
    private float durationAni = 4.0f;
    void Start()
    {
        //khoi tao controller
        controller = GetComponent<CharacterController>();
    }
    Vector3 moveVector;
    // Update is called once per frame
    void Update()
    {
        if(Time.time<durationAni)
        {
            controller.Move(Vector3.forward * speed * Time.deltaTime);//di chuyen theo truc z
            return;
        }
        moveVector = Vector3.zero;//khoi tao vec to di chuyen
        if(controller.isGrounded)//neu cham mat san
        {
            verticalVelocity=-0.1f;
        }
        else
        {
            verticalVelocity -= gravity*Time.deltaTime;//tuong tac trong luc theo thoi gian 
        }
        //theo truc x (sang phai, trai)
        moveVector.x = Input.GetAxisRaw("Horizontal") * speed;
        //theo truc y (len, xuong)
        moveVector.y = verticalVelocity;
        //theo truc z (chuyen dong vao trong)
        moveVector.z = speed;
        controller.Move(moveVector * Time.deltaTime);
    }

    public void SetSpeed(float m)//ham thay doi toc do theo thoi gian
    {
        speed = 5.0f+m;
    }
}
