﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMotor : MonoBehaviour
{
    private Transform lookAt;//diem theo doi
    private Vector3 startOS;//khoang cach 
    private Vector3 moveVT;//vector di chuyen
    private float transition;//ks noi suy
    private float animationTime = 4.0f;//thoi gian animation
    //khoi tao
    private Vector3 animationOffet = new Vector3(0,5,5);
    // Start is called before the first frame update
    void Start()
    {
        //anh xa
        lookAt = GameObject.FindGameObjectWithTag("Player").transform;//anh xa doi tuong theo tag
        //khoi tao khoang cach offset
        startOS = transform.position - lookAt.position;
    }

    // Update is called once per frame
    void Update()
    {
        //camera di chuyen
        moveVT = lookAt.position + startOS;
        //theo X
        moveVT.x=0f;
        //theo Y
        moveVT.y = Mathf.Clamp(moveVT.y,5,5);
        if(transition > 1.0f)
        {
            transform.position = moveVT;//di chuyen theo nv
        }
        else
        {
            transform.position = Vector3.Lerp(moveVT+animationOffet,moveVT,transition);
            transition += Time.deltaTime * 1/animationTime;
            transform.LookAt(lookAt.position + Vector3.up);
        }

    }
}
